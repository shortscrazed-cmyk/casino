# 🚀 MYUPSTAKE Casino - Быстрый старт

## Что изменено:
✅ Название изменено с "CRASH" на "MYUPSTAKE"
✅ Кнопка Place Bet работает корректно
✅ Система сохранения кредитов в MongoDB активна
✅ Готово к упаковке и деплою

## Установка и запуск

### 1. Backend
```bash
cd crash-casino-app/backend
pip install -r requirements.txt
# Настройте .env файл с вашими данными MongoDB
python -m uvicorn server:app --host 0.0.0.0 --port 8001 --reload
```

### 2. Frontend
```bash
cd crash-casino-app/frontend
yarn install
# Настройте .env файл с URL вашего backend
yarn start
```

### 3. MongoDB
Убедитесь что MongoDB запущен:
- Локально: `mongodb://localhost:27017`
- Или используйте MongoDB Atlas (бесплатно)

## Особенности

### Кнопка Place Bet
Кнопка **Place Bet** видна только в состоянии "waiting" (ожидание):
- Во время обратного отсчета (10 секунд)
- Когда у вас достаточно баланса
- До начала игры

После размещения ставки кнопка меняется на **Cash Out**.

### Система кредитов (звезд ⭐)
- Стартовый баланс: 1000 ⭐
- Все ставки сохраняются в MongoDB
- Баланс автоматически обновляется
- История игр сохраняется

## Telegram Mini App

Для подключения к Telegram:
1. Создайте бота через @BotFather
2. Настройте Mini App: `/newapp`
3. Укажите URL вашего деплоя
4. Название: **MYUPSTAKE Casino**

## Деплой

### Рекомендуется: Render.com
**Backend:**
- Build: `pip install -r requirements.txt`
- Start: `uvicorn server:app --host 0.0.0.0 --port $PORT`

**Frontend:**
- Build: `yarn install && yarn build`
- Publish: `build`

**MongoDB:**
- MongoDB Atlas (free tier)

## Поддержка
Для вопросов и проблем обращайтесь к документации в README.md

---
**Сделано с ⚡ для Telegram Mini Apps**
