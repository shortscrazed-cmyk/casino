import math
import random
import hashlib
from datetime import datetime

class CrashGame:
    """Crash game logic with provably fair algorithm"""
    
    def __init__(self, house_edge=0.03):
        self.house_edge = house_edge
        self.current_multiplier = 1.0
        self.crash_point = None
        self.game_state = "waiting"  # waiting, playing, crashed
        self.bets = []  # List of active bets
        self.game_history = []  # Last games results
        
    def generate_crash_point(self, seed=None):
        """Generate crash point using provably fair algorithm with house edge"""
        if seed is None:
            seed = str(random.random())
        
        # Generate hash
        hash_value = hashlib.sha256(seed.encode()).hexdigest()
        
        # Convert first 8 chars to number between 0 and 1
        hash_int = int(hash_value[:8], 16)
        hash_float = hash_int / (16**8)
        
        # Apply house edge (3%)
        hash_float = hash_float * (1 - self.house_edge)
        
        # Calculate crash point using inverse of the hash
        # Formula: crash_point = 99 / (1 - hash_float)
        # This gives us a distribution similar to real crash games
        if hash_float >= 0.99:
            crash_point = 1.0
        else:
            crash_point = 99 / (100 - (hash_float * 100))
        
        # Round to 2 decimal places and ensure minimum is 1.00
        crash_point = max(1.0, round(crash_point, 2))
        
        return crash_point
    
    def start_game(self):
        """Start a new game"""
        self.crash_point = self.generate_crash_point()
        self.current_multiplier = 1.0
        self.game_state = "playing"
        self.bets = []  # Reset bets for new game
        return self.crash_point
    
    def update_multiplier(self, elapsed_time):
        """Update multiplier based on elapsed time (in seconds)"""
        # Exponential growth: multiplier = e^(0.2 * time)
        self.current_multiplier = round(math.exp(0.2 * elapsed_time), 2)
        
        # Check if game should crash
        if self.current_multiplier >= self.crash_point:
            self.current_multiplier = self.crash_point
            self.game_state = "crashed"
        
        return self.current_multiplier
    
    def place_bet(self, user_id, username, amount):
        """Place a bet for the current game"""
        bet = {
            "user_id": user_id,
            "username": username,
            "amount": amount,
            "cash_out_multiplier": None,
            "profit": 0,
            "status": "active",  # active, cashed_out, lost
            "timestamp": datetime.utcnow().isoformat()
        }
        self.bets.append(bet)
        return bet
    
    def cash_out(self, user_id, multiplier):
        """Cash out a bet at current multiplier"""
        for bet in self.bets:
            if bet["user_id"] == user_id and bet["status"] == "active":
                bet["cash_out_multiplier"] = multiplier
                bet["profit"] = round(bet["amount"] * multiplier - bet["amount"], 2)
                bet["status"] = "cashed_out"
                return bet
        return None
    
    def end_game(self):
        """End the current game and update history"""
        self.game_state = "crashed"
        
        # Mark all active bets as lost
        for bet in self.bets:
            if bet["status"] == "active":
                bet["status"] = "lost"
                bet["profit"] = -bet["amount"]
        
        # Add to history
        game_result = {
            "crash_point": self.crash_point,
            "timestamp": datetime.utcnow().isoformat(),
            "bets": self.bets.copy()
        }
        self.game_history.append(game_result)
        
        # Keep only last 25 games
        if len(self.game_history) > 25:
            self.game_history = self.game_history[-25:]
        
        return game_result
    
    def get_history_stats(self):
        """Get statistics from game history"""
        if not self.game_history:
            return {"recent_crashes": [], "streak": {"type": "none", "count": 0}}
        
        recent_crashes = [game["crash_point"] for game in self.game_history[-25:]]
        
        # Calculate streak (above or below 2.00x)
        streak_type = "high" if recent_crashes[-1] >= 2.0 else "low"
        streak_count = 0
        
        for crash_point in reversed(recent_crashes):
            if streak_type == "high" and crash_point >= 2.0:
                streak_count += 1
            elif streak_type == "low" and crash_point < 2.0:
                streak_count += 1
            else:
                break
        
        return {
            "recent_crashes": recent_crashes,
            "streak": {"type": streak_type, "count": streak_count}
        }
